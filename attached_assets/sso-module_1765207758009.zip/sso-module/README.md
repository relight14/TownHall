# Ledewire Cross-Site SSO Module

This module enables single sign-on across all *.ledewire.com subdomains.

## Requirements

- Node.js 18+ (uses native fetch API) or add a fetch polyfill
- Express.js
- cookie-parser middleware

## Quick Setup

1. Copy the `sso-module` folder to your project
2. Install dependencies: `npm install cookie-parser`
3. Add cookie-parser middleware to your Express app
4. Import and use the SSO routes

## Integration Steps

### 1. Add cookie-parser middleware (in your main app file)

```typescript
import cookieParser from "cookie-parser";
const app = express();
app.use(cookieParser());
```

### 2. Add the session endpoint (minimal integration)

```typescript
import { createSSORoutes } from "./sso-module/sso-routes";

// You need to provide your Ledewire API client
const ssoRoutes = createSSORoutes({
  refreshToken: async (refreshToken: string) => {
    // Call Ledewire API to refresh the token
    // Return { access_token, refresh_token } or null on failure
  },
  findUserByLedewireId: async (ledewireUserId: string) => {
    // Optional: Find user in your database
    // Return user object or null
  },
  updateUserTokens: async (userId: string, accessToken: string, refreshToken: string) => {
    // Optional: Update user tokens in your database
  }
});

app.use("/api/auth", ssoRoutes);
```

### 3. Set cookie on login (if your site handles login)

```typescript
import { setSSoCookie } from "./sso-module/sso-helpers";

// After successful login
setSSoCookie(res, ledewireRefreshToken);
```

### 4. Frontend: Check session on page load

```typescript
async function checkSession() {
  try {
    const response = await fetch("/api/auth/session", { credentials: "include" });
    if (response.ok) {
      const data = await response.json();
      // User is authenticated
      // data.ledewireToken contains the access token
    }
  } catch (error) {
    // Not authenticated
  }
}
```

## Files

- `sso-helpers.ts` - Cookie helper functions
- `sso-routes.ts` - Express routes for session/logout
- `sso-types.ts` - TypeScript types

## Cookie Details

- Name: `ledewire_sso`
- Domain: `.ledewire.com` (production) / localhost (development)
- Expiry: 30 days
- Flags: HttpOnly, Secure (production), SameSite=Lax

## Custom Cookie Options

For staging environments or non-ledewire domains, you can override cookie settings:

```typescript
const ssoRoutes = createSSORoutes({
  refreshToken: async (token) => { /* ... */ },
  cookieOptions: {
    domain: '.staging.example.com',  // Custom domain
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days instead of 30
    secure: true,                     // Force secure even in dev
  }
});
```
